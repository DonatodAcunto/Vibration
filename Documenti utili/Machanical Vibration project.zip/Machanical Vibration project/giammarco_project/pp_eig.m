%pp_eig
close all;

for i = 1:3
    print2file(w_f(i),'report\result\','%3.4f','\n','txt',['w_f_' num2str(i,1)])
        for j = 1:3
            print2file(U_eig_f(j,i),'report\result\','%3.4f','\n','txt',['U_f_' num2str(j,1) num2str(i,1)])
        end
end




for i = 1:3
    print2file(w_p(i),'report\result\','%3.4f','\n','txt',['w_p_' num2str(i,1)])
            for j = 1:3
            print2file(U_eig_p(j,i),'report\result\','%3.4f','\n','txt',['U_p_' num2str(j,1) num2str(i,1)])
            end
end